#ifndef UTILITY_H_
#define UTILITY_H_
#include "individual.h"

namespace utility {
bool FitnessCmp(individual::Individual* i1, individual::Individual* i2);
} // namespace utility

#endif // UTILITY_H_